from typing import Any

from insightface.app.common import Face
from roop.FaceSet import FaceSet
import numpy

Face = Face
FaceSet = FaceSet
Frame = numpy.ndarray[Any, Any]
