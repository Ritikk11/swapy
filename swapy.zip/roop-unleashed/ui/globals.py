ui_restart_server = False

SELECTION_FACES_DATA = None
ui_SELECTED_INPUT_FACE_INDEX = 0

ui_selected_enhancer = None
ui_upscale = None
ui_blend_ratio = None
ui_input_thumbs = []
ui_target_thumbs = []
ui_camera_frame = None
ui_selected_swap_model = None





